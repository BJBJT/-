package com.example.modelhub

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.arm.aichat.AiChat
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Msg(val role: String, val text: String)

/** 所有后端共用的接口。 */
interface Backend {
    fun chat(history: List<Msg>): String
    fun close() {}
}

/** OpenAI 兼容接口 (Ollama / LM Studio / vLLM / OpenAI)。spec: <base_url>#<model>。 */
class ApiBackend(spec: String, private val key: String) : Backend {
    private val base = spec.substringBefore('#').trimEnd('/')
    private val model = spec.substringAfter('#', "")

    override fun chat(history: List<Msg>): String {
        val msgs = JSONArray(history.map { JSONObject().put("role", it.role).put("content", it.text) })
        val body = JSONObject().put("model", model).put("messages", msgs).toString()
        val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 120000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer ${key.ifBlank { "none" }}")
        c.outputStream.use { it.write(body.toByteArray()) }
        val ok = c.responseCode < 400
        val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) error("HTTP ${c.responseCode}: ${text.take(200)}")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }
}

/** 手机本地推理: MediaPipe LLM Inference, 加载 .task / .bin 模型 (如 Gemma)。 */
class TaskBackend(path: String, ctx: Context) : Backend {
    private val llm = LlmInference.createFromOptions(
        ctx,
        LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(1024).build()
    )

    // Gemma 的对话模板; 换其他模型时改这里
    private fun prompt(h: List<Msg>) = h.joinToString("") {
        "<start_of_turn>${if (it.role == "user") "user" else "model"}\n${it.text}<end_of_turn>\n"
    } + "<start_of_turn>model\n"

    override fun chat(history: List<Msg>): String = llm.generateResponse(prompt(history))
    override fun close() = llm.close()
}

/** 手机本地 GGUF: Arm 的 ai-chat 库 (基于 llama.cpp)。引擎自己保存对话上下文, 所以只发最新一条。 */
class GgufBackend(path: String, ctx: Context) : Backend {
    private val engine = AiChat.getInferenceEngine(ctx)

    init {
        // 首次使用时把模型复制到应用内部存储, 之后直接读内部副本
        val src = File(path)
        val local = File(ctx.filesDir, src.name)
        if (!local.exists() || local.length() != src.length()) src.copyTo(local, overwrite = true)
        runBlocking { engine.loadModel(local.absolutePath) }
    }

    override fun chat(history: List<Msg>): String = runBlocking {
        engine.sendUserPrompt(history.last().text, predictLength = 512).toList().joinToString("")
    }

    override fun close() = engine.destroy()
}

/** spec: api:<url>#<model> | task:<路径> | gguf:<路径>; 无前缀按扩展名判断。 */
fun createBackend(spec: String, key: String, ctx: Context): Backend {
    val kind = spec.substringBefore(':')
    val rest = spec.substringAfter(':')
    return when {
        kind == "api" -> ApiBackend(rest, key)
        kind == "task" -> TaskBackend(rest, ctx)
        kind == "gguf" -> GgufBackend(rest, ctx)
        spec.endsWith(".gguf") -> GgufBackend(spec, ctx)
        spec.endsWith(".task") || spec.endsWith(".bin") -> TaskBackend(spec, ctx)
        else -> error("无法识别的模型: $spec")
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App(applicationContext) } } }
    }
}

@Composable
fun App(ctx: Context) {
    val scope = rememberCoroutineScope()
    var spec by remember { mutableStateOf("api:http://192.168.1.10:11434/v1#llama3") }
    var key by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("未装载") }
    var busy by remember { mutableStateOf(false) }
    var backend by remember { mutableStateOf<Backend?>(null) }
    val history = remember { mutableStateListOf<Msg>() }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(spec, { spec = it }, Modifier.fillMaxWidth(), label = { Text("模型 spec") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(key, { key = it }, Modifier.weight(1f), label = { Text("API Key (可空)") }, singleLine = true)
            Button(enabled = !busy, onClick = {
                busy = true
                status = "装载中..."
                scope.launch {
                    runCatching { withContext(Dispatchers.IO) { backend?.close(); createBackend(spec, key, ctx) } }
                        .onSuccess { backend = it; history.clear(); status = "已装载" }
                        .onFailure { backend = null; status = "错误: ${it.message}" }
                    busy = false
                }
            }) { Text("装载") }
        }
        Text(status, style = MaterialTheme.typography.labelMedium)
        LazyColumn(Modifier.weight(1f)) {
            items(history) { Text("${if (it.role == "user") "我" else "AI"}: ${it.text}", Modifier.padding(vertical = 4.dp)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), label = { Text("输入消息") })
            Button(enabled = backend != null && !busy && input.isNotBlank(), onClick = {
                val b = backend ?: return@Button
                history.add(Msg("user", input))
                input = ""
                busy = true
                scope.launch {
                    runCatching { withContext(Dispatchers.IO) { b.chat(history.toList()) } }
                        .onSuccess { history.add(Msg("assistant", it)) }
                        .onFailure { history.removeAt(history.lastIndex); status = "错误: ${it.message}" }
                    busy = false
                }
            }) { Text("发送") }
        }
    }
}

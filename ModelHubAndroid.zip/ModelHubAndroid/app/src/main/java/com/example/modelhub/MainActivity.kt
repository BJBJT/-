package com.example.modelhub

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color as CColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import com.arm.aichat.AiChat
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.ceil

/** images: data URL 列表 (图片/视频抽帧/PDF页); shown: 气泡里显示的文字 */
data class Msg(val role: String, val text: String, val images: List<String> = emptyList(), val shown: String = text)

interface Backend {
    fun chat(history: List<Msg>): String
    fun close() {}
}

/** OpenAI 兼容接口 (支持图片: image_url)。spec: <base_url>#<model>。 */
class ApiBackend(spec: String, private val keyOf: () -> String) : Backend {
    private val base = spec.substringBefore('#').trimEnd('/')
    private val model = spec.substringAfter('#', "")

    override fun chat(history: List<Msg>): String {
        val msgs = JSONArray()
        history.forEach { m ->
            val content: Any = if (m.images.isEmpty()) m.text else JSONArray().apply {
                put(JSONObject().put("type", "text").put("text", m.text))
                m.images.forEach {
                    put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", it)))
                }
            }
            msgs.put(JSONObject().put("role", m.role).put("content", content))
        }
        val body = JSONObject().put("model", model).put("messages", msgs).toString()
        val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 180000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer ${keyOf().ifBlank { "none" }}")
        c.outputStream.use { it.write(body.toByteArray()) }
        val ok = c.responseCode < 400
        val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) error("HTTP ${c.responseCode}: ${text.take(300)}")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }
}

/** 本地 MediaPipe (.task / .bin, 如 Gemma)。 */
class TaskBackend(path: String, ctx: Context) : Backend {
    private val llm = LlmInference.createFromOptions(
        ctx, LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(1024).build()
    )

    private fun prompt(h: List<Msg>) = h.joinToString("") {
        "<start_of_turn>${if (it.role == "user") "user" else "model"}\n${it.text}<end_of_turn>\n"
    } + "<start_of_turn>model\n"

    override fun chat(history: List<Msg>): String = llm.generateResponse(prompt(history))
    override fun close() = llm.close()
}

/** 本地 GGUF: Arm ai-chat (llama.cpp)。引擎自己保存上下文, 只发最新一条。 */
class GgufBackend(path: String, ctx: Context) : Backend {
    private val engine = AiChat.getInferenceEngine(ctx)

    init {
        val src = File(path)
        val local = File(ctx.filesDir, src.name)
        if (!local.exists() || local.length() != src.length()) src.copyTo(local, overwrite = true)
        runBlocking { engine.loadModel(local.absolutePath) }
    }

    override fun chat(history: List<Msg>): String = runBlocking {
        engine.sendUserPrompt(history.last().text, predictLength = 512).toList().joinToString("")
    }

    override fun close() = engine.destroy()
}

fun createBackend(spec: String, key: () -> String, ctx: Context): Backend {
    val kind = spec.substringBefore(':')
    val rest = spec.substringAfter(':')
    return when {
        kind == "api" -> ApiBackend(rest, key)
        kind == "task" -> TaskBackend(rest, ctx)
        kind == "gguf" -> GgufBackend(rest, ctx)
        spec.endsWith(".gguf") -> GgufBackend(spec, ctx)
        spec.endsWith(".task") || spec.endsWith(".bin") -> TaskBackend(spec, ctx)
        else -> error("无法识别的模型: $spec")
    }
}

// ---------- 附件处理: 图片 / 视频抽帧 / PDF / 文本 ----------
fun dataUrl(b: Bitmap, max: Int = 1280): String {
    val s = max.toFloat() / maxOf(b.width, b.height)
    val bm = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
    val out = ByteArrayOutputStream()
    bm.compress(Bitmap.CompressFormat.JPEG, 85, out)
    return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
}

fun imageUrl(ctx: Context, uri: Uri): String = dataUrl(
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = 1280f / maxOf(info.size.width, info.size.height)
        if (s < 1f) d.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
    }
)

/** 每分钟抽 perMinute 帧 (24 帧/分钟 = 每 2.5 秒一帧), 最多 maxFrames 帧, 超长视频会均匀稀疏。 */
fun videoFrames(ctx: Context, uri: Uri, perMinute: Int = 24, maxFrames: Int = 60): List<String> {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong() * 1000
        val n = ceil(dur / 60_000_000.0 * perMinute).toInt().coerceIn(1, maxFrames)
        return (0 until n).mapNotNull { i ->
            r.getFrameAtTime(dur * (2 * i + 1) / (2 * n), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?.let { dataUrl(it, 640) }
        }
    } finally {
        r.release()
    }
}

fun fileName(ctx: Context, uri: Uri): String = runCatching {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
}.getOrNull() ?: "文件"

/** PDF -> 前 4 页转图片; 其他 -> 当文本读取 (前 2 万字)。返回 (图片, 追加到提问里的文字)。 */
fun readFile(ctx: Context, uri: Uri): Pair<List<String>, String> {
    val cr = ctx.contentResolver
    val name = fileName(ctx, uri)
    if (cr.getType(uri) == "application/pdf") {
        PdfRenderer(cr.openFileDescriptor(uri, "r")!!).use { r ->
            val imgs = (0 until minOf(r.pageCount, 4)).map { i ->
                r.openPage(i).use { p ->
                    val bmp = Bitmap.createBitmap(1000, 1000 * p.height / p.width, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    dataUrl(bmp)
                }
            }
            return imgs to "\n\n(PDF「$name」前 ${imgs.size} 页已作为图片附上)"
        }
    }
    val text = cr.openInputStream(uri)!!.bufferedReader().use { it.readText() }.take(20000)
    return emptyList<String>() to "\n\n[文件 $name]\n$text"
}

// ---------- 界面 (按设计稿: 首页 / 模型广场 / 对话 / 我的·接入设置) ----------
/** 模型目录。url 以 http 开头 = 云端 API; 否则是本地 spec (gguf:/… 或 task:/…)。 */
data class M(
    val name: String, val vendor: String, val url: String, val model: String, val tag: String, val cat: String,
    val vision: Boolean = false, val custom: Boolean = false, val key: String = ""
) {
    val id get() = "$name|$model"
    val local get() = !url.startsWith("http")
}

val builtin = listOf(
    M("DeepSeek V4 Flash", "DeepSeek", "https://api.deepseek.com", "deepseek-v4-flash", "快速 · 1M 上下文", "对话"),
    M("DeepSeek V4 Pro", "DeepSeek", "https://api.deepseek.com", "deepseek-v4-pro", "旗舰 · 1M 上下文", "对话"),
    M("DeepSeek V4 Flash 视觉(实验)", "DeepSeek", "https://api.deepseek.com", "deepseek-v4-flash-vision-exp", "识图 · 实验版", "识图", true),
    M("DeepSeek V4 Flash (硅基流动)", "硅基流动", "https://api.siliconflow.cn/v1", "deepseek-ai/DeepSeek-V4-Flash", "第三方托管", "对话"),
    M("GPT-4o mini", "OpenAI", "https://api.openai.com/v1", "gpt-4o-mini", "多模态 · 识图", "识图", true),
    M("通义千问 VL", "阿里云", "https://dashscope.aliyuncs.com/compatible-mode/v1", "qwen-vl-plus", "中文 · 识图", "识图", true),
    M("智谱 GLM-4V Flash", "智谱", "https://open.bigmodel.cn/api/paas/v4", "glm-4v-flash", "识图", "识图", true),
    M("Kimi", "Moonshot", "https://api.moonshot.cn/v1", "moonshot-v1-8k", "对话", "对话"),
    M("Gemini 2.5 Flash", "Google", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.5-flash", "多模态 · 识图", "识图", true),
    M("Llama 3.3 70B", "Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "开源 · 对话", "对话"),
)

fun specOf(m: M) = if (m.local) m.url else "api:${m.url}#${m.model}"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App(applicationContext) } } }
    }
}

@Composable
fun Avatar(t: String, size: Int = 40) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(CColor.hsv((kotlin.math.abs(t.hashCode()) % 360).toFloat(), 0.45f, 0.9f)),
        contentAlignment = Alignment.Center
    ) { Text(t.take(1), color = CColor.White, fontWeight = FontWeight.Bold) }
}

@Composable
fun Bubble(m: Msg) {
    val me = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (me) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 320.dp)
        ) { SelectionContainer { Text(m.shown, Modifier.padding(12.dp)) } }
    }
}

@Composable
fun ModelCard(m: M, selected: Boolean, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Avatar(m.vendor)
            Column(Modifier.weight(1f)) {
                Text(m.name, fontWeight = FontWeight.SemiBold)
                Text("${m.vendor} · ${m.tag}", style = MaterialTheme.typography.labelSmall)
            }
            if (selected) Text("✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
    }
}

data class Tile(val icon: String, val label: String, val act: () -> Unit)

@Composable
fun App(ctx: Context) {
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("modelhub", Context.MODE_PRIVATE) }
    val customs = remember {
        mutableStateListOf<M>().apply {
            val a = JSONArray(prefs.getString("custom", "[]"))
            for (i in 0 until a.length()) a.getJSONObject(i).let {
                val u = it.getString("url")
                add(M(it.getString("name"), "自定义", u, it.getString("model"), if (u.startsWith("http")) "自定义 API" else "本地模型", "自定义", custom = true, key = it.optString("key")))
            }
        }
    }
    val keys = remember {
        mutableStateMapOf<String, String>().apply {
            builtin.map { it.vendor }.distinct().forEach { put(it, prefs.getString("key_$it", "") ?: "") }
        }
    }
    val off = remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("off", emptySet())!!) } }
    val models = builtin + customs
    val enabled = models.filter { it.id !in off }
    var cur by remember { mutableStateOf(models.firstOrNull { it.id == prefs.getString("sel", "") } ?: builtin[0]) }
    var tab by remember { mutableIntStateOf(0) }
    var cat by remember { mutableStateOf("全部") }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var switchMenu by remember { mutableStateOf(false) }
    var attachMenu by remember { mutableStateOf(false) }
    var backend by remember { mutableStateOf<Backend?>(null) }
    val history = remember { mutableStateListOf<Msg>() }
    val pendImgs = remember { mutableStateListOf<String>() }
    val pendNotes = remember { mutableStateListOf<String>() }
    var pendText by remember { mutableStateOf("") }
    var cName by remember { mutableStateOf("") }
    var cUrl by remember { mutableStateOf("") }
    var cModel by remember { mutableStateOf("") }
    var cKey by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(history.size) { if (history.isNotEmpty()) listState.animateScrollToItem(history.lastIndex) }

    fun keyOf(m: M) = if (m.custom) m.key else keys[m.vendor] ?: ""

    fun select(m: M) {
        busy = true
        status = "切换到 ${m.name}..."
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { backend?.close(); createBackend(specOf(m), { keyOf(m) }, ctx) } }
                .onSuccess {
                    if (!(backend is ApiBackend && it is ApiBackend)) history.clear()
                    backend = it; cur = m
                    prefs.edit().putString("sel", m.id).apply()
                    status = if (!m.local && keyOf(m).isBlank()) "还没填 API Key,请到「我的」里填写" else ""
                }
                .onFailure { backend = null; status = "错误: ${it.message}" }
            busy = false
        }
    }
    LaunchedEffect(Unit) { select(cur) }

    fun attach(note: String, work: () -> Pair<List<String>, String>) {
        busy = true
        status = "处理附件..."
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { work() } }
                .onSuccess { (imgs, text) -> pendImgs.addAll(imgs); pendText += text; pendNotes.add(note); status = "" }
                .onFailure { status = "附件错误: ${it.message}" }
            busy = false
        }
    }

    val pickImg = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) attach("🖼×${uris.size}") { uris.map { imageUrl(ctx, it) } to "" }
    }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { attach("🎞 视频") { val f = videoFrames(ctx, it); f to "\n\n(以上 ${f.size} 张图片是视频按时间顺序均匀抽取的画面)" } }
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { attach("📎 ${fileName(ctx, it)}") { readFile(ctx, it) } }
    }
    val speak = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input += it }
    }
    fun startSpeech() {
        runCatching {
            speak.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }.onFailure { status = "本机没有可用的语音识别服务" }
    }

    fun send() {
        val b = backend ?: return
        if (pendImgs.isNotEmpty() && b !is ApiBackend) { status = "本地模型不支持图片/视频,请切换到云端模型"; return }
        if (pendImgs.isNotEmpty() && !(cur.vision || cur.custom)) { status = "当前模型不能识图,请在顶部切换到带 🖼 的模型"; return }
        val q = input.ifBlank { "请识别并描述这些内容。" }
        history.add(Msg("user", q + pendText, pendImgs.toList(), (pendNotes.joinToString(" ") + "\n" + input).trim()))
        input = ""; pendImgs.clear(); pendNotes.clear(); pendText = ""
        busy = true
        status = "思考中..."
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { b.chat(history.toList()) } }
                .onSuccess { history.add(Msg("assistant", it)); status = "" }
                .onFailure { history.removeAt(history.lastIndex); status = "错误: ${it.message}" }
            busy = false
        }
    }

    fun toChat(block: () -> Unit = {}) { tab = 2; block() }
    val tiles = listOf(
        Tile("💬", "对话") { toChat() },
        Tile("🖼", "识图") { toChat { pickImg.launch("image/*") } },
        Tile("🎞", "视频") { toChat { pickVideo.launch("video/*") } },
        Tile("📄", "文档") { toChat { pickFile.launch("*/*") } },
        Tile("🎤", "语音") { toChat { startSpeech() } },
        Tile("💻", "代码") { toChat { input = "请帮我写代码:" } },
        Tile("🌐", "翻译") { toChat { input = "请把下面内容翻译成英文:\n" } },
        Tile("⋯", "更多") { tab = 1 },
    )

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text("AI 多模型助手", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("一个应用,连接所有 AI", style = MaterialTheme.typography.labelMedium)
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Box(
                            Modifier.background(Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer))).padding(20.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("汇聚全球顶尖 AI 模型", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                Text("对话、识图、读文档、看视频、语音输入,你想要的这里都有。", color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }
                    }
                    tiles.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { t ->
                                Column(Modifier.weight(1f).clickable { t.act() }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
                                        Text(t.icon, fontSize = 24.sp)
                                    }
                                    Text(t.label, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                    Text("当前模型", fontWeight = FontWeight.SemiBold)
                    ModelCard(cur, true) { tab = 1 }
                }

                1 -> Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("模型广场", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("全部", "对话", "识图", "自定义").forEach { c ->
                            FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
                        }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                        items(enabled.filter { cat == "全部" || it.cat == cat }) { m ->
                            ModelCard(m, m.id == cur.id) { select(m); tab = 2 }
                        }
                    }
                }

                2 -> Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) {
                            Row(Modifier.clickable { switchMenu = true }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Avatar(cur.vendor, 36)
                                Column {
                                    Text(cur.name + " ▾", fontWeight = FontWeight.SemiBold)
                                    Text(status.ifEmpty { cur.vendor }, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            DropdownMenu(switchMenu, { switchMenu = false }) {
                                enabled.forEach { m ->
                                    DropdownMenuItem(
                                        text = { Text((if (m.id == cur.id) "✓ " else "") + m.name + (if (m.vision) " 🖼" else "")) },
                                        onClick = { switchMenu = false; select(m) }
                                    )
                                }
                            }
                        }
                        TextButton(onClick = { history.clear(); if (cur.local) select(cur) }) { Text("新对话") }
                    }
                    LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(history) { Bubble(it) }
                    }
                    if (pendNotes.isNotEmpty()) {
                        AssistChip(onClick = { pendImgs.clear(); pendNotes.clear(); pendText = "" }, label = { Text("${pendNotes.joinToString(" ")}  ✕") })
                    }
                    Row(Modifier.padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box {
                            TextButton(onClick = { attachMenu = true }) { Text("＋") }
                            DropdownMenu(attachMenu, { attachMenu = false }) {
                                DropdownMenuItem(text = { Text("图片") }, onClick = { attachMenu = false; pickImg.launch("image/*") })
                                DropdownMenuItem(text = { Text("视频") }, onClick = { attachMenu = false; pickVideo.launch("video/*") })
                                DropdownMenuItem(text = { Text("文件 (PDF/文本)") }, onClick = { attachMenu = false; pickFile.launch("*/*") })
                            }
                        }
                        OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("输入你的问题…") }, maxLines = 4, shape = RoundedCornerShape(20.dp))
                        TextButton(onClick = { startSpeech() }) { Text("🎤") }
                        Button(enabled = backend != null && !busy && (input.isNotBlank() || pendNotes.isNotEmpty()), onClick = { send() }) { Text("发送") }
                    }
                }

                else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Avatar("我", 56)
                        Column {
                            Text("接入设置", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Key 只保存在本机", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Text("API Key", fontWeight = FontWeight.SemiBold)
                    keys.keys.toList().sorted().forEach { v ->
                        OutlinedTextField(
                            keys[v] ?: "", { keys[v] = it; prefs.edit().putString("key_$v", it).apply() },
                            Modifier.fillMaxWidth(), label = { Text("$v API Key") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                    }
                    Text("已接入的模型", fontWeight = FontWeight.SemiBold)
                    models.forEach { m ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Avatar(m.vendor, 32)
                            Column(Modifier.weight(1f)) {
                                Text(m.name)
                                Text(m.vendor, style = MaterialTheme.typography.labelSmall)
                            }
                            if (m.custom) TextButton(onClick = {
                                customs.remove(m)
                                prefs.edit().putString("custom", JSONArray(customs.map { JSONObject().put("name", it.name).put("url", it.url).put("model", it.model).put("key", it.key) }).toString()).apply()
                            }) { Text("删除") }
                            Switch(checked = m.id !in off, onCheckedChange = { on ->
                                if (on) off.remove(m.id) else off.add(m.id)
                                prefs.edit().putStringSet("off", off.toSet()).apply()
                            })
                        }
                    }
                    Text("接入自定义 API", fontWeight = FontWeight.SemiBold)
                    Text("兼容 OpenAI 接口即可;本地模型把地址写成 gguf:/路径 或 task:/路径", style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(cName, { cName = it }, Modifier.fillMaxWidth(), label = { Text("显示名称") }, singleLine = true)
                    OutlinedTextField(cUrl, { cUrl = it }, Modifier.fillMaxWidth(), label = { Text("接口地址 (如 https://api.xxx.com/v1)") }, singleLine = true)
                    OutlinedTextField(cModel, { cModel = it }, Modifier.fillMaxWidth(), label = { Text("模型名 (如 deepseek-v4-pro)") }, singleLine = true)
                    OutlinedTextField(cKey, { cKey = it }, Modifier.fillMaxWidth(), label = { Text("API Key (可空)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                    Button(enabled = cName.isNotBlank() && cUrl.isNotBlank(), onClick = {
                        val u = cUrl.trim()
                        customs.add(M(cName.trim(), "自定义", u, cModel.trim(), if (u.startsWith("http")) "自定义 API" else "本地模型", "自定义", custom = true, key = cKey.trim()))
                        prefs.edit().putString("custom", JSONArray(customs.map { JSONObject().put("name", it.name).put("url", it.url).put("model", it.model).put("key", it.key) }).toString()).apply()
                        cName = ""; cUrl = ""; cModel = ""; cKey = ""
                    }) { Text("添加") }
                }
            }
        }
        NavigationBar {
            listOf("🏠" to "首页", "🧩" to "模型", "💬" to "对话", "👤" to "我的").forEachIndexed { i, (ic, t) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(ic) }, label = { Text(t) })
            }
        }
    }
}

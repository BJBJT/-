package com.example.modelhub

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color as CColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.sp
import android.content.ContentValues
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.provider.MediaStore
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.unit.dp
import com.arm.aichat.AiChat
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.ceil

/** images: data URL 列表 (图片/视频抽帧/PDF页); shown: 气泡里显示的文字 */
data class Msg(val role: String, val text: String, val images: List<String> = emptyList(), val shown: String = text)

interface Backend {
    fun chat(history: List<Msg>): String
    fun close() {}
    fun image(prompt: String): String = error("该后端不支持绘图")
}

/** OpenAI 兼容接口: 对话(含 image_url 识图) + 绘图 (/images/generations)。spec: <base_url>#<model>。 */
class ApiBackend(spec: String, private val keyOf: () -> String) : Backend {
    private val base = spec.substringBefore('#').trimEnd('/')
    private val model = spec.substringAfter('#', "")

    private fun post(path: String, body: String): String {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 180000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer ${keyOf().ifBlank { "none" }}")
        c.outputStream.use { it.write(body.toByteArray()) }
        val ok = c.responseCode < 400
        val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) error("HTTP ${c.responseCode}: ${text.take(300)}")
        return text
    }

    override fun chat(history: List<Msg>): String {
        val msgs = JSONArray()
        history.filter { it.role == "user" || it.text.isNotBlank() }.forEach { m ->
            val content: Any = if (m.role != "user" || m.images.isEmpty()) m.text else JSONArray().apply {
                put(JSONObject().put("type", "text").put("text", m.text))
                m.images.forEach {
                    put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", it)))
                }
            }
            msgs.put(JSONObject().put("role", m.role).put("content", content))
        }
        val text = post("/chat/completions", JSONObject().put("model", model).put("messages", msgs).toString())
        return JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "")
    }

    override fun image(prompt: String): String {
        val body = JSONObject().put("model", model).put("prompt", prompt).put("n", 1).put("size", "1024x1024").toString()
        val j = JSONObject(post("/images/generations", body)).getJSONArray("data").getJSONObject(0)
        val bytes = if (j.has("b64_json")) Base64.decode(j.getString("b64_json"), Base64.DEFAULT) else URL(j.getString("url")).readBytes()
        return dataUrl(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
    }
}

/** 本地 MediaPipe (.task / .bin, 如 Gemma)。 */
class TaskBackend(path: String, ctx: Context) : Backend {
    private val llm = LlmInference.createFromOptions(
        ctx, LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(1024).build()
    )

    private fun prompt(h: List<Msg>) = h.joinToString("") {
        "<start_of_turn>${if (it.role == "user") "user" else "model"}\n${it.text}<end_of_turn>\n"
    } + "<start_of_turn>model\n"

    override fun chat(history: List<Msg>): String = llm.generateResponse(prompt(history))
    override fun close() = llm.close()
}

/** 本地 GGUF: Arm ai-chat (llama.cpp)。引擎自己保存上下文, 只发最新一条。 */
class GgufBackend(path: String, ctx: Context) : Backend {
    private val engine = AiChat.getInferenceEngine(ctx)

    init {
        val src = File(path)
        val local = File(ctx.filesDir, src.name)
        if (!local.exists() || local.length() != src.length()) src.copyTo(local, overwrite = true)
        runBlocking { engine.loadModel(local.absolutePath) }
    }

    override fun chat(history: List<Msg>): String = runBlocking {
        engine.sendUserPrompt(history.last().text, predictLength = 512).toList().joinToString("")
    }

    override fun close() = engine.destroy()
}

fun createBackend(spec: String, key: () -> String, ctx: Context): Backend {
    val kind = spec.substringBefore(':')
    val rest = spec.substringAfter(':')
    return when {
        kind == "api" -> ApiBackend(rest, key)
        kind == "task" -> TaskBackend(rest, ctx)
        kind == "gguf" -> GgufBackend(rest, ctx)
        spec.endsWith(".gguf") -> GgufBackend(spec, ctx)
        spec.endsWith(".task") || spec.endsWith(".bin") -> TaskBackend(spec, ctx)
        else -> error("无法识别的模型: $spec")
    }
}

// ---------- 附件处理: 图片 / 视频抽帧 / PDF / 文本 ----------
fun dataUrl(b: Bitmap, max: Int = 1280): String {
    val s = max.toFloat() / maxOf(b.width, b.height)
    val bm = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
    val out = ByteArrayOutputStream()
    bm.compress(Bitmap.CompressFormat.JPEG, 85, out)
    return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
}

fun imageUrl(ctx: Context, uri: Uri): String = dataUrl(
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = 1280f / maxOf(info.size.width, info.size.height)
        if (s < 1f) d.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
    }
)

/** 每分钟抽 perMinute 帧 (24 帧/分钟 = 每 2.5 秒一帧), 最多 maxFrames 帧, 超长视频会均匀稀疏。 */
fun videoFrames(ctx: Context, uri: Uri, perMinute: Int = 24, maxFrames: Int = 60): List<String> {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong() * 1000
        val n = ceil(dur / 60_000_000.0 * perMinute).toInt().coerceIn(1, maxFrames)
        return (0 until n).mapNotNull { i ->
            r.getFrameAtTime(dur * (2 * i + 1) / (2 * n), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?.let { dataUrl(it, 640) }
        }
    } finally {
        r.release()
    }
}

fun fileName(ctx: Context, uri: Uri): String = runCatching {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
}.getOrNull() ?: "文件"

/** PDF -> 前 4 页转图片; 其他 -> 当文本读取 (前 2 万字)。返回 (图片, 追加到提问里的文字)。 */
fun readFile(ctx: Context, uri: Uri): Pair<List<String>, String> {
    val cr = ctx.contentResolver
    val name = fileName(ctx, uri)
    if (cr.getType(uri) == "application/pdf") {
        PdfRenderer(cr.openFileDescriptor(uri, "r")!!).use { r ->
            val imgs = (0 until minOf(r.pageCount, 4)).map { i ->
                r.openPage(i).use { p ->
                    val bmp = Bitmap.createBitmap(1000, 1000 * p.height / p.width, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    dataUrl(bmp)
                }
            }
            return imgs to "\n\n(PDF「$name」前 ${imgs.size} 页已作为图片附上)"
        }
    }
    val text = cr.openInputStream(uri)!!.bufferedReader().use { it.readText() }.take(20000)
    return emptyList<String>() to "\n\n[文件 $name]\n$text"
}

// ---------- 对话持久化 (历史对话) ----------
data class Conv(val id: Long, val title: String, val model: String, val time: Long)

fun convFile(ctx: Context, id: Long) = File(ctx.filesDir, "chat_$id.json")

fun saveConv(ctx: Context, prefs: SharedPreferences, id: Long, model: String, msgs: List<Msg>) {
    val arr = JSONArray(msgs.map { JSONObject().put("r", it.role).put("t", it.text).put("s", it.shown).put("i", JSONArray(it.images)) })
    convFile(ctx, id).writeText(arr.toString())
    val idx = JSONArray(prefs.getString("idx", "[]"))
    val list = (0 until idx.length()).map { idx.getJSONObject(it) }.filter { it.getLong("id") != id }.toMutableList()
    val title = msgs.firstOrNull { it.role == "user" }?.shown?.replace("\n", " ")?.take(24) ?: "新对话"
    list.add(0, JSONObject().put("id", id).put("title", title).put("model", model).put("time", System.currentTimeMillis()))
    prefs.edit().putString("idx", JSONArray(list).toString()).apply()
}

fun loadIndex(prefs: SharedPreferences): List<Conv> {
    val a = JSONArray(prefs.getString("idx", "[]"))
    return (0 until a.length()).map { a.getJSONObject(it) }.map { Conv(it.getLong("id"), it.getString("title"), it.getString("model"), it.getLong("time")) }
}

fun loadConv(ctx: Context, id: Long): List<Msg> {
    val a = JSONArray(convFile(ctx, id).readText())
    return (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
        val im = o.getJSONArray("i")
        Msg(o.getString("r"), o.getString("t"), (0 until im.length()).map { im.getString(it) }, o.getString("s"))
    }
}

fun deleteConv(ctx: Context, prefs: SharedPreferences, id: Long) {
    convFile(ctx, id).delete()
    prefs.edit().putString("idx", JSONArray(loadIndex(prefs).filter { it.id != id }.map {
        JSONObject().put("id", it.id).put("title", it.title).put("model", it.model).put("time", it.time)
    }).toString()).apply()
}

fun fmt(t: Long): String = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(t))

fun saveImage(ctx: Context, url: String): Boolean = runCatching {
    val bytes = Base64.decode(url.substringAfter(","), Base64.DEFAULT)
    val v = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "modelhub_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ModelHub")
    }
    val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
    ctx.contentResolver.openOutputStream(u)!!.use { it.write(bytes) }
}.isSuccess

// ---------- 模型目录 ----------
/** url 以 http 开头 = 云端 API; 否则是本地 spec (gguf:/… 或 task:/…)。gen = 绘图模型。 */
data class M(
    val name: String, val vendor: String, val url: String, val model: String, val tag: String, val cat: String,
    val vision: Boolean = false, val custom: Boolean = false, val key: String = "", val gen: Boolean = false
) {
    val id get() = "$name|$model"
    val local get() = !url.startsWith("http")
}

const val DS = "https://api.deepseek.com"
const val OAI = "https://api.openai.com/v1"
const val ANT = "https://api.anthropic.com/v1"
const val GEM = "https://generativelanguage.googleapis.com/v1beta/openai"
const val XAI = "https://api.x.ai/v1"
const val MOON = "https://api.moonshot.cn/v1"
const val ZP = "https://open.bigmodel.cn/api/paas/v4"
const val ALI = "https://dashscope.aliyuncs.com/compatible-mode/v1"
const val ARK = "https://ark.cn-beijing.volces.com/api/v3"
const val SF = "https://api.siliconflow.cn/v1"

val builtin = listOf(
    M("DeepSeek V4.1 Flash", "DeepSeek", DS, "deepseek-flash", "快速 · 1M 上下文", "对话"),
    M("DeepSeek V4 Flash", "DeepSeek", DS, "deepseek-v4-flash", "快速 · 1M 上下文", "对话"),
    M("DeepSeek V4 Pro", "DeepSeek", DS, "deepseek-v4-pro", "旗舰 · 1M 上下文", "对话"),
    M("DeepSeek V4 Flash 视觉(实验)", "DeepSeek", DS, "deepseek-v4-flash-vision-exp", "识图 · 实验版", "识图", true),
    M("GPT-5.5", "OpenAI", OAI, "gpt-5.5", "旗舰 · 多模态", "识图", true),
    M("GPT-5.4 mini", "OpenAI", OAI, "gpt-5.4-mini", "轻量 · 多模态", "识图", true),
    M("Claude Opus 5.5", "Anthropic", ANT, "claude-opus-5-5", "高端 · 长文本 · 多模态", "识图", true),
    M("Claude Sonnet 5.5", "Anthropic", ANT, "claude-sonnet-5-5", "均衡 · 编程 · 多模态", "识图", true),
    M("Claude Haiku 5.5", "Anthropic", ANT, "claude-haiku-5-5", "快速 · 多模态", "识图", true),
    M("Gemini 3.5 Flash", "Google", GEM, "gemini-3.5-flash", "多模态 · 长上下文", "识图", true),
    M("Gemini Pro (最新)", "Google", GEM, "gemini-pro-latest", "多模态 · 推理", "识图", true),
    M("Grok 4.3", "xAI", XAI, "grok-4.3", "对话 · 多模态", "识图", true),
    M("Kimi K2.6", "Moonshot", MOON, "kimi-k2.6", "长文本 · 多模态", "识图", true),
    M("GLM-5V Turbo", "智谱", ZP, "glm-5v-turbo", "中文 · 识图", "识图", true),
    M("GLM-5.1", "智谱", ZP, "glm-5.1", "中文 · 对话", "对话"),
    M("通义千问 VL", "阿里云", ALI, "qwen-vl-plus", "中文 · 识图", "识图", true),
    M("通义千问 Plus", "阿里云", ALI, "qwen-plus", "中文 · 创作", "对话"),
    M("豆包 Seed 2.1 Turbo", "火山方舟", ARK, "doubao-seed-2-1-turbo-260628", "多模态 · 中文", "识图", true),
    M("Mistral Large", "Mistral", "https://api.mistral.ai/v1", "mistral-large-latest", "欧洲 · 对话", "对话"),
    M("Llama 3.3 70B", "Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "开源 · 极速", "对话"),
    M("DeepSeek V4 Flash (硅基流动)", "硅基流动", SF, "deepseek-ai/DeepSeek-V4-Flash", "第三方托管", "对话"),
    M("GPT Image 2", "OpenAI", OAI, "gpt-image-2", "文字生成图片", "绘图", gen = true),
    M("CogView-4", "智谱", ZP, "cogview-4-250304", "文字生成图片", "绘图", gen = true),
    M("FLUX.2 dev", "DeepInfra", "https://api.deepinfra.com/v1/openai", "black-forest-labs/FLUX-2-dev", "文字生成图片", "绘图", gen = true),
)

fun specOf(m: M) = if (m.local) m.url else "api:${m.url}#${m.model}"

// ---------- 界面 ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val p = remember { getSharedPreferences("modelhub", MODE_PRIVATE) }
            var theme by remember { mutableIntStateOf(p.getInt("theme", 0)) }
            val dark = if (theme == 0) isSystemInDarkTheme() else theme == 2
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface { App(applicationContext, theme) { theme = it; p.edit().putInt("theme", it).apply() } }
            }
        }
    }
}

@Composable
fun Avatar(t: String, size: Int = 40) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(CColor.hsv((kotlin.math.abs(t.hashCode()) % 360).toFloat(), 0.45f, 0.9f)),
        contentAlignment = Alignment.Center
    ) { Text(t.take(1), color = CColor.White, fontWeight = FontWeight.Bold) }
}

@Composable
fun Thumb(url: String, modifier: Modifier, big: Boolean = false, onClick: () -> Unit = {}) {
    val bmp = remember(url) {
        runCatching {
            val b = Base64.decode(url.substringAfter(","), Base64.DEFAULT)
            BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = if (big) 1 else 2 })?.asImageBitmap()
        }.getOrNull()
    }
    if (bmp != null) Image(bmp, null, modifier.clip(RoundedCornerShape(12.dp)).clickable { onClick() }, contentScale = if (big) ContentScale.Fit else ContentScale.Crop)
}

@Composable
fun Bubble(m: Msg, onImage: (String) -> Unit) {
    val me = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (me) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (m.images.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        m.images.take(6).forEach { Thumb(it, Modifier.size(if (me) 100.dp else 260.dp)) { onImage(it) } }
                    }
                    if (m.images.size > 6) Text("…共 ${m.images.size} 张", style = MaterialTheme.typography.labelSmall)
                }
                if (m.shown.isNotBlank()) SelectionContainer { Text(m.shown) }
            }
        }
    }
}

@Composable
fun ModelCard(m: M, selected: Boolean, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Avatar(m.vendor)
            Column(Modifier.weight(1f)) {
                Text(m.name, fontWeight = FontWeight.SemiBold)
                Text("${m.vendor} · ${m.tag}", style = MaterialTheme.typography.labelSmall)
            }
            if (selected) Text("✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Top(title: String, back: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) TextButton(onClick = back) { Text("‹ 返回") }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = if (back == null) 16.dp else 0.dp))
    }
}

data class Tile(val icon: String, val label: String, val act: () -> Unit)
data class Tool(val icon: String, val name: String, val desc: String, val cat: String, val act: () -> Unit)

@Composable
fun App(ctx: Context, theme: Int, onTheme: (Int) -> Unit) {
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("modelhub", Context.MODE_PRIVATE) }
    fun jsonOf(l: List<M>) = JSONArray(l.map { JSONObject().put("name", it.name).put("url", it.url).put("model", it.model).put("key", it.key).put("gen", it.gen) }).toString()
    val customs = remember {
        mutableStateListOf<M>().apply {
            val a = JSONArray(prefs.getString("custom", "[]"))
            for (i in 0 until a.length()) a.getJSONObject(i).let {
                val u = it.getString("url")
                add(M(it.getString("name"), "自定义", u, it.getString("model"), if (u.startsWith("http")) "自定义 API" else "本地模型", if (it.optBoolean("gen")) "绘图" else "自定义", custom = true, key = it.optString("key"), gen = it.optBoolean("gen")))
            }
        }
    }
    val keys = remember { mutableStateMapOf<String, String>().apply { builtin.map { it.vendor }.distinct().forEach { put(it, prefs.getString("key_$it", "") ?: "") } } }
    val off = remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("off", emptySet())!!) } }
    val models = builtin + customs
    val enabled = models.filter { it.id !in off }
    var cur by remember { mutableStateOf(models.firstOrNull { it.id == prefs.getString("sel", "") } ?: builtin[0]) }
    var tab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<M?>(null) }
    var cat by remember { mutableStateOf("全部") }
    var tcat by remember { mutableStateOf("全部") }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var switchMenu by remember { mutableStateOf(false) }
    var attachMenu by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<Pair<String, String>?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var vendorSel by remember { mutableStateOf<String?>(null) }
    var backend by remember { mutableStateOf<Backend?>(null) }
    var convId by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var convs by remember { mutableStateOf(loadIndex(prefs)) }
    val history = remember { mutableStateListOf<Msg>() }
    val pendImgs = remember { mutableStateListOf<String>() }
    val pendNotes = remember { mutableStateListOf<String>() }
    var pendText by remember { mutableStateOf("") }
    var cName by remember { mutableStateOf("") }
    var cUrl by remember { mutableStateOf("") }
    var cModel by remember { mutableStateOf("") }
    var cKey by remember { mutableStateOf("") }
    var cGen by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    LaunchedEffect(history.size) { if (history.isNotEmpty()) listState.animateScrollToItem(history.lastIndex) }

    fun keyOf(m: M) = if (m.custom) m.key else keys[m.vendor] ?: ""

    fun select(m: M) {
        busy = true
        status = "切换到 ${m.name}..."
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { backend?.close(); createBackend(specOf(m), { keyOf(m) }, ctx) } }
                .onSuccess {
                    if (!(backend is ApiBackend && it is ApiBackend)) history.clear()
                    backend = it; cur = m
                    prefs.edit().putString("sel", m.id).apply()
                    status = if (!m.local && keyOf(m).isBlank()) "还没填 API Key,请到「我的 → 模型管理」填写" else ""
                }
                .onFailure { backend = null; status = "错误: ${it.message}" }
            busy = false
        }
    }
    LaunchedEffect(Unit) { select(cur) }

    fun newChat() {
        history.clear(); pendImgs.clear(); pendNotes.clear(); pendText = ""
        convId = System.currentTimeMillis()
        if (cur.local) select(cur)
    }

    fun attach(note: String, work: () -> Pair<List<String>, String>) {
        busy = true
        status = "处理附件..."
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { work() } }
                .onSuccess { (imgs, text) -> pendImgs.addAll(imgs); pendText += text; pendNotes.add(note); status = "" }
                .onFailure { status = "附件错误: ${it.message}" }
            busy = false
        }
    }

    val pickImg = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) attach("🖼×${uris.size}") { uris.map { imageUrl(ctx, it) } to "" }
    }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { attach("🎞 视频") { val f = videoFrames(ctx, it); f to "\n\n(以上 ${f.size} 张图片是视频按时间顺序均匀抽取的画面)" } }
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { attach("📎 ${fileName(ctx, it)}") { readFile(ctx, it) } }
    }
    val speak = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input += it }
    }
    fun startSpeech() {
        runCatching {
            speak.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }.onFailure { status = "本机没有可用的语音识别服务" }
    }

    fun send() {
        val b = backend ?: return
        val gen = cur.gen
        if (!gen && pendImgs.isNotEmpty() && b !is ApiBackend) { status = "本地模型不支持图片/视频,请切换到云端模型"; return }
        if (!gen && pendImgs.isNotEmpty() && !(cur.vision || cur.custom)) { status = "当前模型不能识图,请在顶部切换到带 🖼 的模型"; return }
        val q = input.ifBlank { if (gen) return else "请识别并描述这些内容。" }
        history.add(Msg("user", q + (if (gen) "" else pendText), if (gen) emptyList() else pendImgs.toList(), (pendNotes.joinToString(" ") + "\n" + input).trim()))
        input = ""; pendImgs.clear(); pendNotes.clear(); pendText = ""
        val snapshot = history.toList()
        busy = true
        status = if (gen) "生成中..." else "思考中..."
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { if (gen) b.image(q) else b.chat(snapshot) } }
                .onSuccess {
                    history.add(if (gen) Msg("assistant", "", listOf(it), "点击图片可放大/保存") else Msg("assistant", it))
                    status = ""
                    val snap = history.toList()
                    withContext(Dispatchers.IO) { saveConv(ctx, prefs, convId, cur.name, snap) }
                    convs = loadIndex(prefs)
                }
                .onFailure { history.removeAt(history.lastIndex); status = "错误: ${it.message}" }
            busy = false
        }
    }

    fun toChat(block: () -> Unit = {}) { tab = 2; sub = ""; block() }
    fun useGen() { enabled.firstOrNull { it.gen }?.let { select(it) }; toChat() }
    fun openConv(c: Conv) {
        runCatching { val l = loadConv(ctx, c.id); history.clear(); history.addAll(l); convId = c.id; toChat() }
            .onFailure { status = "打开失败: ${it.message}" }
    }
    val tiles = listOf(
        Tile("💬", "对话") { toChat() },
        Tile("🎨", "绘图") { useGen() },
        Tile("🖼", "识图") { toChat { pickImg.launch("image/*") } },
        Tile("🎞", "视频") { toChat { pickVideo.launch("video/*") } },
        Tile("📄", "文档") { toChat { pickFile.launch("*/*") } },
        Tile("💻", "代码") { toChat { input = "请帮我写代码:" } },
        Tile("🌐", "翻译") { toChat { input = "请把下面内容翻译成英文:\n" } },
        Tile("⋯", "工具箱") { sub = "tools" },
    )
    val tools = listOf(
        Tool("🎨", "图片生成", "文字生成高质量图片", "娱乐") { useGen() },
        Tool("📄", "文档解析", "PDF / 文本文件", "效率") { toChat { pickFile.launch("*/*") } },
        Tool("🖼", "图片识别", "相册图片提问", "学习") { toChat { pickImg.launch("image/*") } },
        Tool("🎞", "视频理解", "抽帧识别视频内容", "学习") { toChat { pickVideo.launch("video/*") } },
        Tool("🌐", "翻译工具", "多语言互译", "效率") { toChat { input = "请把下面内容翻译成英文:\n" } },
        Tool("🎤", "语音输入", "语音转文字", "生活") { toChat { startSpeech() } },
        Tool("💻", "代码助手", "写代码 / 调试", "效率") { toChat { input = "请帮我写代码:" } },
        Tool("🧠", "思维导图", "生成多级大纲", "学习") { toChat { input = "请用 Markdown 多级列表为下面的主题生成思维导图大纲:\n" } },
        Tool("✍", "创意写作", "文案 / 故事 / 邮件", "娱乐") { toChat { input = "请帮我写:" } },
    )

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                sub == "tools" -> Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Top("工具箱") { sub = "" }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("全部", "效率", "学习", "娱乐", "生活").forEach { c -> FilterChip(selected = tcat == c, onClick = { tcat = c }, label = { Text(c) }) }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(tools.filter { tcat == "全部" || it.cat == tcat }) { t ->
                            Card(onClick = t.act, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) { Text(t.icon, fontSize = 22.sp) }
                                    Column(Modifier.weight(1f)) { Text(t.name, fontWeight = FontWeight.SemiBold); Text(t.desc, style = MaterialTheme.typography.labelSmall) }
                                    Text("使用", color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }

                sub == "history" -> Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Top("历史对话") { sub = "" }
                    if (convs.isEmpty()) Text("还没有对话记录")
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(convs) { c ->
                            Card(onClick = { openConv(c) }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Avatar(c.model)
                                    Column(Modifier.weight(1f)) { Text(c.title, fontWeight = FontWeight.SemiBold, maxLines = 1); Text("${c.model} · ${fmt(c.time)}", style = MaterialTheme.typography.labelSmall) }
                                    TextButton(onClick = { deleteConv(ctx, prefs, c.id); convs = loadIndex(prefs) }) { Text("删除") }
                                }
                            }
                        }
                    }
                }

                sub == "detail" && detail != null -> {
                    val m = detail!!
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Top("模型详情") { sub = ""; tab = 1 }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Avatar(m.vendor, 64)
                            Column { Text(m.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(m.vendor) }
                        }
                        Text("${m.tag}\n模型名: ${m.model}\n接口: ${if (m.local) m.url else m.url}")
                        Text("能力", fontWeight = FontWeight.SemiBold)
                        Text(buildList { add("💬 文本对话"); if (m.vision || m.custom) add("🖼 图像理解"); if (m.vision || m.custom) add("🎞 视频抽帧理解"); if (m.gen) add("🎨 文字生成图片"); add("📄 文档问答") }.joinToString("   "))
                        Text("适用场景", fontWeight = FontWeight.SemiBold)
                        Text("• 日常问答\n• 文档总结\n• 创意写作\n• 编程助手\n• 多语言翻译")
                        Button(onClick = { select(m); toChat() }, modifier = Modifier.fillMaxWidth()) { Text("开始使用") }
                    }
                }

                sub == "settings" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Top("接入设置") { sub = "" }
                    Text("API Key (只保存在本机)", fontWeight = FontWeight.SemiBold)
                    keys.keys.toList().sorted().forEach { v ->
                        OutlinedTextField(
                            keys[v] ?: "", { keys[v] = it; prefs.edit().putString("key_$v", it).apply() },
                            Modifier.fillMaxWidth(), label = { Text("$v API Key") }, singleLine = true, visualTransformation = PasswordVisualTransformation()
                        )
                    }
                    Text("已接入的模型", fontWeight = FontWeight.SemiBold)
                    models.forEach { m ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Avatar(m.vendor, 32)
                            Column(Modifier.weight(1f)) { Text(m.name); Text(m.vendor, style = MaterialTheme.typography.labelSmall) }
                            if (m.custom) TextButton(onClick = { customs.remove(m); prefs.edit().putString("custom", jsonOf(customs.toList())).apply() }) { Text("删除") }
                            Switch(checked = m.id !in off, onCheckedChange = { on ->
                                if (on) off.remove(m.id) else off.add(m.id)
                                prefs.edit().putStringSet("off", off.toSet()).apply()
                            })
                        }
                    }
                    Text("接入自定义 API", fontWeight = FontWeight.SemiBold)
                    Text("兼容 OpenAI 接口即可;本地模型把地址写成 gguf:/路径 或 task:/路径", style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(cName, { cName = it }, Modifier.fillMaxWidth(), label = { Text("显示名称") }, singleLine = true)
                    OutlinedTextField(cUrl, { cUrl = it }, Modifier.fillMaxWidth(), label = { Text("接口地址 (如 https://api.xxx.com/v1)") }, singleLine = true)
                    OutlinedTextField(cModel, { cModel = it }, Modifier.fillMaxWidth(), label = { Text("模型名") }, singleLine = true)
                    OutlinedTextField(cKey, { cKey = it }, Modifier.fillMaxWidth(), label = { Text("API Key (可空)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("这是绘图模型", Modifier.weight(1f)); Switch(cGen, { cGen = it }) }
                    Button(enabled = cName.isNotBlank() && cUrl.isNotBlank(), onClick = {
                        val u = cUrl.trim()
                        customs.add(M(cName.trim(), "自定义", u, cModel.trim(), if (u.startsWith("http")) "自定义 API" else "本地模型", if (cGen) "绘图" else "自定义", custom = true, key = cKey.trim(), gen = cGen))
                        prefs.edit().putString("custom", jsonOf(customs.toList())).apply()
                        cName = ""; cUrl = ""; cModel = ""; cKey = ""; cGen = false
                    }) { Text("添加") }
                    Spacer(Modifier.height(16.dp))
                }

                tab == 0 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("AI 多模型助手", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("一个应用,连接所有 AI", style = MaterialTheme.typography.labelMedium)
                        }
                        TextButton(onClick = { sub = "settings" }) { Text("⚙") }
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Box(Modifier.background(Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer))).padding(20.dp)) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("汇聚全球顶尖 AI 模型", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                Text("写作、绘图、编程、翻译、识图,你想要的这里都有。", color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }
                    }
                    tiles.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { t ->
                                Column(Modifier.weight(1f).clickable { t.act() }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) { Text(t.icon, fontSize = 24.sp) }
                                    Text(t.label, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("最近对话", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { sub = "history" }) { Text("更多 ›") }
                    }
                    if (convs.isEmpty()) Text("还没有对话,去聊聊吧", style = MaterialTheme.typography.labelMedium)
                    convs.take(3).forEach { c ->
                        Card(onClick = { openConv(c) }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Avatar(c.model, 36)
                                Column { Text(c.title, maxLines = 1); Text("${c.model} · ${fmt(c.time)}", style = MaterialTheme.typography.labelSmall) }
                            }
                        }
                    }
                }

                tab == 1 -> Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Top("模型广场")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("全部", "对话", "识图", "绘图", "自定义").forEach { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                        items(enabled.filter { cat == "全部" || it.cat == cat }.groupBy { it.vendor }.toList()) { (v, ms) ->
                            Card(onClick = { vendorSel = v }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Avatar(v)
                                    Column(Modifier.weight(1f)) {
                                        Text(v, fontWeight = FontWeight.SemiBold)
                                        Text("${ms.size} 个模型 · " + ms.joinToString("、") { it.name }, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                                    }
                                    if (cur.vendor == v) Text("✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                tab == 2 -> Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) {
                            Row(Modifier.clickable { switchMenu = true }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Avatar(cur.vendor, 36)
                                Column {
                                    Text(cur.name + " ▾", fontWeight = FontWeight.SemiBold)
                                    Text(status.ifEmpty { cur.vendor }, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            DropdownMenu(switchMenu, { switchMenu = false }) {
                                enabled.forEach { m ->
                                    DropdownMenuItem(text = { Text((if (m.id == cur.id) "✓ " else "") + m.name + (if (m.vision) " 🖼" else "") + (if (m.gen) " 🎨" else "")) }, onClick = { switchMenu = false; select(m) })
                                }
                            }
                        }
                        TextButton(onClick = { sub = "history" }) { Text("历史") }
                        TextButton(onClick = { newChat() }) { Text("新对话") }
                    }
                    LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(history) { Bubble(it) { u -> viewer = u } }
                    }
                    if (pendImgs.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        pendImgs.take(8).forEach { Thumb(it, Modifier.size(64.dp)) { viewer = it } }
                    }
                    if (pendNotes.isNotEmpty()) AssistChip(onClick = { pendImgs.clear(); pendNotes.clear(); pendText = "" }, label = { Text("${pendNotes.joinToString(" ")}  ✕") })
                    Row(Modifier.padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box {
                            TextButton(onClick = { attachMenu = true }) { Text("＋") }
                            DropdownMenu(attachMenu, { attachMenu = false }) {
                                DropdownMenuItem(text = { Text("图片") }, onClick = { attachMenu = false; pickImg.launch("image/*") })
                                DropdownMenuItem(text = { Text("视频") }, onClick = { attachMenu = false; pickVideo.launch("video/*") })
                                DropdownMenuItem(text = { Text("文件 (PDF/文本)") }, onClick = { attachMenu = false; pickFile.launch("*/*") })
                            }
                        }
                        OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text(if (cur.gen) "描述你想生成的画面…" else "输入你的问题…") }, maxLines = 4, shape = RoundedCornerShape(20.dp))
                        TextButton(onClick = { startSpeech() }) { Text("🎤") }
                        Button(enabled = backend != null && !busy && (input.isNotBlank() || (!cur.gen && pendNotes.isNotEmpty())), onClick = { send() }) { Text("发送") }
                    }
                }

                else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                        Avatar("我", 64)
                        Column { Text("本机用户", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("数据只保存在本机", style = MaterialTheme.typography.labelSmall) }
                    }
                    listOf(
                        Tile("历史对话", "${convs.size} 个") { sub = "history" },
                        Tile("模型管理", "") { sub = "settings" },
                        Tile("工具箱", "") { sub = "tools" },
                        Tile("外观主题", listOf("跟随系统", "浅色", "深色")[theme]) { onTheme((theme + 1) % 3) },
                        Tile("清空历史对话", "") { confirmClear = true },
                        Tile("关于我们", "") { info = "关于我们" to "ModelHub · 一个应用连接多个 AI 模型。\n聊天记录和 API Key 只保存在你的手机里。" },
                        Tile("帮助与反馈", "") { info = "帮助与反馈" to "1. API Key 在各服务商控制台获取,填在「模型管理」。\n2. 报错时先看对话页顶部的状态文字。\n3. 模型名可能随服务商更新,不对时用「接入自定义 API」改。" },
                    ).forEach { (label, value, act) ->
                        Row(Modifier.fillMaxWidth().clickable { act() }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(label, Modifier.weight(1f)); Text("$value ›", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
        NavigationBar {
            listOf("🏠" to "首页", "🧩" to "模型", "💬" to "对话", "👤" to "我的").forEachIndexed { i, (ic, t) ->
                NavigationBarItem(selected = tab == i && sub.isEmpty(), onClick = { tab = i; sub = "" }, icon = { Text(ic) }, label = { Text(t) })
            }
        }
    }

    viewer?.let { u ->
        Dialog(onDismissRequest = { viewer = null }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Thumb(u, Modifier.fillMaxWidth().heightIn(max = 480.dp), big = true)
                    Row {
                        TextButton(onClick = { status = if (saveImage(ctx, u)) "已保存到相册 Pictures/ModelHub" else "保存失败"; viewer = null }) { Text("保存") }
                        TextButton(onClick = { viewer = null }) { Text("关闭") }
                    }
                }
            }
        }
    }
    vendorSel?.let { v ->
        Dialog(onDismissRequest = { vendorSel = null }) {
            Surface(shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Avatar(v)
                        Text(v, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { vendorSel = null }) { Text("关闭") }
                    }
                    if (v in keys.keys) OutlinedTextField(
                        keys[v] ?: "", { keys[v] = it; prefs.edit().putString("key_$v", it).apply() },
                        Modifier.fillMaxWidth(), label = { Text("$v API Key") }, singleLine = true, visualTransformation = PasswordVisualTransformation()
                    )
                    Text("选择模型", fontWeight = FontWeight.SemiBold)
                    Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        enabled.filter { it.vendor == v }.forEach { m ->
                            Card(onClick = { select(m); vendorSel = null; toChat() }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text((if (m.id == cur.id) "✓ " else "") + m.name, fontWeight = FontWeight.SemiBold)
                                        Text(m.tag + (if (m.vision) " · 🖼" else "") + (if (m.gen) " · 🎨" else ""), style = MaterialTheme.typography.labelSmall)
                                    }
                                    TextButton(onClick = { detail = m; sub = "detail"; vendorSel = null }) { Text("详情") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    info?.let { (t, s) -> AlertDialog(onDismissRequest = { info = null }, confirmButton = { TextButton(onClick = { info = null }) { Text("好") } }, title = { Text(t) }, text = { Text(s) }) }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        confirmButton = { TextButton(onClick = { convs.forEach { deleteConv(ctx, prefs, it.id) }; convs = loadIndex(prefs); confirmClear = false }) { Text("清空") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("取消") } },
        title = { Text("清空历史对话") }, text = { Text("所有已保存的对话会被删除,不能恢复。") }
    )
}

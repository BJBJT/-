package com.example.modelhub

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.RecognizerIntent
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.arm.aichat.AiChat
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.ceil

/** images: data URL 列表 (图片/视频抽帧/PDF页); shown: 气泡里显示的文字 */
data class Msg(val role: String, val text: String, val images: List<String> = emptyList(), val shown: String = text)

interface Backend {
    fun chat(history: List<Msg>): String
    fun close() {}
}

/** OpenAI 兼容接口 (支持图片: image_url)。spec: <base_url>#<model>。 */
class ApiBackend(spec: String, private val key: String) : Backend {
    private val base = spec.substringBefore('#').trimEnd('/')
    private val model = spec.substringAfter('#', "")

    override fun chat(history: List<Msg>): String {
        val msgs = JSONArray()
        history.forEach { m ->
            val content: Any = if (m.images.isEmpty()) m.text else JSONArray().apply {
                put(JSONObject().put("type", "text").put("text", m.text))
                m.images.forEach {
                    put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", it)))
                }
            }
            msgs.put(JSONObject().put("role", m.role).put("content", content))
        }
        val body = JSONObject().put("model", model).put("messages", msgs).toString()
        val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 180000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer ${key.ifBlank { "none" }}")
        c.outputStream.use { it.write(body.toByteArray()) }
        val ok = c.responseCode < 400
        val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) error("HTTP ${c.responseCode}: ${text.take(300)}")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }
}

/** 本地 MediaPipe (.task / .bin, 如 Gemma)。 */
class TaskBackend(path: String, ctx: Context) : Backend {
    private val llm = LlmInference.createFromOptions(
        ctx, LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(1024).build()
    )

    private fun prompt(h: List<Msg>) = h.joinToString("") {
        "<start_of_turn>${if (it.role == "user") "user" else "model"}\n${it.text}<end_of_turn>\n"
    } + "<start_of_turn>model\n"

    override fun chat(history: List<Msg>): String = llm.generateResponse(prompt(history))
    override fun close() = llm.close()
}

/** 本地 GGUF: Arm ai-chat (llama.cpp)。引擎自己保存上下文, 只发最新一条。 */
class GgufBackend(path: String, ctx: Context) : Backend {
    private val engine = AiChat.getInferenceEngine(ctx)

    init {
        val src = File(path)
        val local = File(ctx.filesDir, src.name)
        if (!local.exists() || local.length() != src.length()) src.copyTo(local, overwrite = true)
        runBlocking { engine.loadModel(local.absolutePath) }
    }

    override fun chat(history: List<Msg>): String = runBlocking {
        engine.sendUserPrompt(history.last().text, predictLength = 512).toList().joinToString("")
    }

    override fun close() = engine.destroy()
}

fun createBackend(spec: String, key: String, ctx: Context): Backend {
    val kind = spec.substringBefore(':')
    val rest = spec.substringAfter(':')
    return when {
        kind == "api" -> ApiBackend(rest, key)
        kind == "task" -> TaskBackend(rest, ctx)
        kind == "gguf" -> GgufBackend(rest, ctx)
        spec.endsWith(".gguf") -> GgufBackend(spec, ctx)
        spec.endsWith(".task") || spec.endsWith(".bin") -> TaskBackend(spec, ctx)
        else -> error("无法识别的模型: $spec")
    }
}

// ---------- 服务商预设 (模型名可能随服务商更新, 可在界面里改) ----------
data class Provider(val name: String, val url: String, val model: String)

val providers = listOf(
    Provider("OpenAI", "https://api.openai.com/v1", "gpt-4o-mini"),
    Provider("DeepSeek", "https://api.deepseek.com/v1", "deepseek-chat"),
    Provider("通义千问", "https://dashscope.aliyuncs.com/compatible-mode/v1", "qwen-vl-plus"),
    Provider("智谱 GLM", "https://open.bigmodel.cn/api/paas/v4", "glm-4v-flash"),
    Provider("Kimi", "https://api.moonshot.cn/v1", "moonshot-v1-8k"),
    Provider("硅基流动", "https://api.siliconflow.cn/v1", "Qwen/Qwen2.5-7B-Instruct"),
    Provider("火山方舟(豆包)", "https://ark.cn-beijing.volces.com/api/v3", "填接入点ID"),
    Provider("OpenRouter", "https://openrouter.ai/api/v1", "openai/gpt-4o-mini"),
    Provider("Groq", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
    Provider("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.5-flash"),
    Provider("Ollama(局域网)", "http://192.168.1.10:11434/v1", "llama3"),
    Provider("本地模型", "", ""),
)

// ---------- 附件处理: 图片 / 视频抽帧 / PDF / 文本 ----------
fun dataUrl(b: Bitmap, max: Int = 1280): String {
    val s = max.toFloat() / maxOf(b.width, b.height)
    val bm = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
    val out = ByteArrayOutputStream()
    bm.compress(Bitmap.CompressFormat.JPEG, 85, out)
    return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
}

fun imageUrl(ctx: Context, uri: Uri): String = dataUrl(
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = 1280f / maxOf(info.size.width, info.size.height)
        if (s < 1f) d.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
    }
)

/** 每分钟抽 perMinute 帧 (24 帧/分钟 = 每 2.5 秒一帧), 最多 maxFrames 帧, 超长视频会均匀稀疏。 */
fun videoFrames(ctx: Context, uri: Uri, perMinute: Int = 24, maxFrames: Int = 60): List<String> {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(ctx, uri)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong() * 1000
        val n = ceil(dur / 60_000_000.0 * perMinute).toInt().coerceIn(1, maxFrames)
        return (0 until n).mapNotNull { i ->
            r.getFrameAtTime(dur * (2 * i + 1) / (2 * n), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?.let { dataUrl(it, 640) }
        }
    } finally {
        r.release()
    }
}

fun fileName(ctx: Context, uri: Uri): String = runCatching {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
}.getOrNull() ?: "文件"

/** PDF -> 前 4 页转图片; 其他 -> 当文本读取 (前 2 万字)。返回 (图片, 追加到提问里的文字)。 */
fun readFile(ctx: Context, uri: Uri): Pair<List<String>, String> {
    val cr = ctx.contentResolver
    val name = fileName(ctx, uri)
    if (cr.getType(uri) == "application/pdf") {
        PdfRenderer(cr.openFileDescriptor(uri, "r")!!).use { r ->
            val imgs = (0 until minOf(r.pageCount, 4)).map { i ->
                r.openPage(i).use { p ->
                    val bmp = Bitmap.createBitmap(1000, 1000 * p.height / p.width, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    dataUrl(bmp)
                }
            }
            return imgs to "\n\n(PDF「$name」前 ${imgs.size} 页已作为图片附上)"
        }
    }
    val text = cr.openInputStream(uri)!!.bufferedReader().use { it.readText() }.take(20000)
    return emptyList<String>() to "\n\n[文件 $name]\n$text"
}

// ---------- 界面 ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App(applicationContext) } } }
    }
}

@Composable
fun Bubble(m: Msg) {
    val me = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (me) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 320.dp)
        ) { SelectionContainer { Text(m.shown, Modifier.padding(12.dp)) } }
    }
}

@Composable
fun App(ctx: Context) {
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("modelhub", Context.MODE_PRIVATE) }
    var pIdx by remember { mutableIntStateOf(prefs.getInt("p", 0).coerceIn(providers.indices)) }
    var url by remember { mutableStateOf(providers[pIdx].url) }
    var model by remember { mutableStateOf(providers[pIdx].model) }
    var key by remember { mutableStateOf(prefs.getString("key_${providers[pIdx].name}", "") ?: "") }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("未装载") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }
    var attachMenu by remember { mutableStateOf(false) }
    var backend by remember { mutableStateOf<Backend?>(null) }
    val history = remember { mutableStateListOf<Msg>() }
    val pendImgs = remember { mutableStateListOf<String>() }
    val pendNotes = remember { mutableStateListOf<String>() }
    var pendText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val local = providers[pIdx].url.isEmpty()
    LaunchedEffect(history.size) { if (history.isNotEmpty()) listState.animateScrollToItem(history.lastIndex) }

    fun attach(note: String, work: () -> Pair<List<String>, String>) {
        busy = true
        status = "处理附件..."
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { work() } }
                .onSuccess { (imgs, text) -> pendImgs.addAll(imgs); pendText += text; pendNotes.add(note); status = "" }
                .onFailure { status = "附件错误: ${it.message}" }
            busy = false
        }
    }

    val pickImg = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) attach("🖼×${uris.size}") { uris.map { imageUrl(ctx, it) } to "" }
    }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { attach("🎞 视频") { val f = videoFrames(ctx, it); f to "\n\n(以上 ${f.size} 张图片是视频按时间顺序均匀抽取的画面)" } }
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { attach("📎 ${fileName(ctx, it)}") { readFile(ctx, it) } }
    }
    val speak = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input += it }
    }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ModelHub", style = MaterialTheme.typography.titleLarge)
                if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.labelSmall)
            }
            TextButton(onClick = { showSettings = !showSettings }) { Text(if (showSettings) "收起" else "设置") }
        }
        if (showSettings) Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box {
                    OutlinedButton(onClick = { menu = true }) { Text("${providers[pIdx].name} ▾") }
                    DropdownMenu(menu, { menu = false }) {
                        providers.forEachIndexed { i, p ->
                            DropdownMenuItem(text = { Text(p.name) }, onClick = {
                                pIdx = i; url = p.url; model = p.model
                                key = prefs.getString("key_${p.name}", "") ?: ""
                                menu = false
                            })
                        }
                    }
                }
                OutlinedTextField(
                    url, { url = it }, Modifier.fillMaxWidth(),
                    label = { Text(if (local) "本地路径 (gguf:/… 或 task:/…)" else "接口地址") }
                )
                if (!local) {
                    OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("模型名") }, singleLine = true)
                    OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API Key") }, singleLine = true)
                }
                Button(enabled = !busy, onClick = {
                    busy = true
                    status = "装载中..."
                    val spec = if (local) url else "api:$url#$model"
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { backend?.close(); createBackend(spec, key, ctx) } }
                            .onSuccess {
                                backend = it; history.clear(); status = "已装载: ${providers[pIdx].name}"; showSettings = false
                                prefs.edit().putInt("p", pIdx).putString("key_${providers[pIdx].name}", key).apply()
                            }
                            .onFailure { backend = null; status = "错误: ${it.message}" }
                        busy = false
                    }
                }) { Text("装载") }
            }
        }
        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(history) { Bubble(it) }
        }
        if (pendNotes.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip(onClick = { pendImgs.clear(); pendNotes.clear(); pendText = "" }, label = { Text("${pendNotes.joinToString(" ")}  ✕") })
        }
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Box {
                TextButton(onClick = { attachMenu = true }) { Text("＋") }
                DropdownMenu(attachMenu, { attachMenu = false }) {
                    DropdownMenuItem(text = { Text("图片") }, onClick = { attachMenu = false; pickImg.launch("image/*") })
                    DropdownMenuItem(text = { Text("视频") }, onClick = { attachMenu = false; pickVideo.launch("video/*") })
                    DropdownMenuItem(text = { Text("文件 (PDF/文本)") }, onClick = { attachMenu = false; pickFile.launch("*/*") })
                }
            }
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("输入消息") }, maxLines = 4)
            TextButton(onClick = {
                runCatching {
                    speak.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
                }.onFailure { status = "本机没有可用的语音识别服务" }
            }) { Text("🎤") }
            Button(
                enabled = backend != null && !busy && (input.isNotBlank() || pendNotes.isNotEmpty()),
                onClick = {
                    val b = backend ?: return@Button
                    if (pendImgs.isNotEmpty() && b !is ApiBackend) { status = "本地模型不支持图片/视频,请用云端 API"; return@Button }
                    val q = input.ifBlank { "请识别并描述这些内容。" }
                    history.add(Msg("user", q + pendText, pendImgs.toList(), (pendNotes.joinToString(" ") + "\n" + input).trim()))
                    input = ""; pendImgs.clear(); pendNotes.clear(); pendText = ""
                    busy = true
                    status = "思考中..."
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { b.chat(history.toList()) } }
                            .onSuccess { history.add(Msg("assistant", it)); status = "" }
                            .onFailure { history.removeAt(history.lastIndex); status = "错误: ${it.message}" }
                        busy = false
                    }
                }
            ) { Text("发送") }
        }
    }
}
